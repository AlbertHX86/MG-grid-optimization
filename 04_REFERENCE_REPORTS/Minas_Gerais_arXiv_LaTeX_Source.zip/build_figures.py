import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd, numpy as np
from pathlib import Path
from matplotlib.ticker import FuncFormatter
root=Path('/mnt/data/MG_arXiv_Paper');out=root/'figures';out.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'axes.labelcolor':'#334155','axes.edgecolor':'#94a3b8','xtick.color':'#475569','ytick.color':'#475569','figure.facecolor':'white','axes.facecolor':'white'})
NAVY='#243a59'; TEAL='#0d9488'; ORANGE='#f59e0b'; PURPLE='#7c6bb0'; RED='#bd4e4e'; GREEN='#51936a';GREY='#a7b1bd';INK='#152339'
# palette
techs=['Utility PV','Distributed PV','Biomass','Small hydro','Wind','Biogas','BESS']
cap2035=[1.000,1.044,.877,.296,0,0,0]
cap2050=[12.9181499072,7.944,.877,.671,2,.4,5.29048402465]
colors=['#2b6689','#86b8bc','#a07955','#6c9eb8','#75a97f','#c59d72','#6f68ab']
fig,ax=plt.subplots(figsize=(8,3.05))
for j,(y,vals) in enumerate([(2035,cap2035),(2050,cap2050)]):
 x=0
 for name,v,col in zip(techs,vals,colors):
  if v>0:
   ax.barh(j,v,left=x,color=col,height=.48,edgecolor='white',linewidth=.6,label=name if j==0 else None)
   if v>.85:ax.text(x+v/2,j,f'{v:.2f}',va='center',ha='center',color='white' if col in ['#2b6689','#6f68ab','#a07955'] else INK,fontsize=8,fontweight='bold')
   x+=v
 ax.text(x+.35,j,f'{x:.3f} GW',va='center',fontsize=9,fontweight='bold',color=INK)
ax.set_yticks([0,1],['2035','2050']);ax.invert_yaxis();ax.set_xlim(0,34);ax.set_xlabel('Incremental capacity (GW; BESS shown by power rating)');ax.grid(axis='x',alpha=.16);ax.set_axisbelow(True)
ax.legend([plt.Rectangle((0,0),1,1,color=c) for c in colors],techs,ncol=4,loc='upper center',bbox_to_anchor=(.5,-.28),frameon=False,fontsize=8,columnspacing=1.2)
fig.subplots_adjust(left=.1,right=.95,bottom=.33,top=.96)
fig.savefig(out/'portfolio_composition.pdf',bbox_inches='tight');fig.savefig(out/'portfolio_composition.png',dpi=185,bbox_inches='tight');plt.close(fig)
# comparative cost chart
local=[1357.87685,5359.38344];region=[878.31998,4607.65757]
fig,ax=plt.subplots(figsize=(7.8,3.1));x=np.arange(2);w=.32
b1=ax.bar(x-w/2,local,w,label='Four-area siting case',color=NAVY)
b2=ax.bar(x+w/2,region,w,label='All-candidate-area siting',color=TEAL)
for bars in [b1,b2]:
 for b in bars:ax.text(b.get_x()+b.get_width()/2,b.get_height()+75,f'{b.get_height():,.0f}',ha='center',va='bottom',fontsize=8)
ax.set_xticks(x,['2035','2050']);ax.set_ylim(0,6200);ax.set_ylabel('Indicative connection cost (million R$)');ax.legend(frameon=False,loc='upper left',ncol=2,fontsize=8);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
fig.tight_layout();fig.savefig(out/'siting_cost.pdf',bbox_inches='tight');fig.savefig(out/'siting_cost.png',dpi=185,bbox_inches='tight');plt.close(fig)
# overload 2050 local/export 2 subplot
scens=['MG-load balancing','Export-stress balancing']; local_pre=[663.306,8779.479];local_post=[160.687,170.847];reg_pre=[677.962,8779.479];reg_post=[164.756,172.307]
fig,axs=plt.subplots(1,2,figsize=(8.4,3.25),gridspec_kw={'wspace':.35})
for ax,i in zip(axs,[0,1]):
 xx=np.arange(2);w=.33
 before=[local_pre[i],reg_pre[i]];after=[local_post[i],reg_post[i]]
 a=ax.bar(xx-w/2,before,w,label='Before parallel circuits',color=NAVY)
 b=ax.bar(xx+w/2,after,w,label='After parallel circuits',color=ORANGE)
 ax.set_xticks(xx,['Local','Regional']);ax.set_title(scens[i],fontsize=10,fontweight='bold');ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True);ax.set_ylim(0,max(before)*1.2)
 for bar in list(a)+list(b):
  ax.text(bar.get_x()+bar.get_width()/2,bar.get_height()+max(before)*.018,f'{bar.get_height():,.0f}',fontsize=7,ha='center')
axs[0].set_ylabel('Worst-case screened overload sum (MW)')
handles,labels=axs[0].get_legend_handles_labels();fig.legend(handles,labels,loc='lower center',ncol=2,bbox_to_anchor=(.5,-.04),frameon=False,fontsize=8)
fig.subplots_adjust(left=.09,right=.98,bottom=.19,top=.87)
fig.savefig(out/'congestion_relieved.pdf',bbox_inches='tight');fig.savefig(out/'congestion_relieved.png',dpi=185,bbox_inches='tight');plt.close(fig)
# residual regional
fig,ax=plt.subplots(figsize=(7.5,2.35))
names=['Timoteo--Aperam  (1646--4475)','Joao Monlevade  (1609--1613)'];vals=[135.610135,29.145756]
y=np.arange(len(names))
ax.barh(y,vals,color=[RED,ORANGE],height=.45)
for yi,v in enumerate(vals):ax.text(v+2,yi,f'{v:.2f} MW',va='center',fontsize=9)
ax.set_yticks(y,names);ax.invert_yaxis();ax.set_xlabel('Residual thermal-limit exceedance under 90% PV coincidence (MW)');ax.set_xlim(0,168);ax.grid(axis='x',alpha=.15);ax.set_axisbelow(True)
fig.subplots_adjust(left=.38,right=.95,top=.95,bottom=.25)
fig.savefig(out/'residual_bottlenecks.pdf',bbox_inches='tight');fig.savefig(out/'residual_bottlenecks.png',dpi=185,bbox_inches='tight');plt.close(fig)
print('figures built')
