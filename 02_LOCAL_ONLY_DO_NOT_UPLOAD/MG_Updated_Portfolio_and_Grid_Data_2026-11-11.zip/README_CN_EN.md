# Minas Gerais | Updated Portfolio + Grid Data (2026-11-11)

## 资料说明 / Contents
本数据包汇集此前实际求解所用的 2035/2050 新增能源组合、8760小时能源输入与调度结果、EPE 2035 规划网架模型、ONS 变电站映射、候选接入节点和局部/区域拥塞扩建结果。

- `01_Energy_Portfolio/`: `portfolio_2035_updated.csv` and `portfolio_2050_updated.csv` are the **latest fixed Step-2 portfolio inputs**, not an earlier 2050 iteration with 12.728 GW BESS. Their `new_build_gw` refers to *incremental capacity*, not total state generation capacity. Also includes hourly dispatch `.csv.gz`, aggregated yearly energy and critical snapshots; `macro_hourly_inputs.csv` contains time-series model inputs.
- `02_Grid_Reference_2035/`: EPE PDE2035 PWF export: **1,489 buses** and **1,890 branches**, along with crosswalk to ONS station coordinates, the 12 research candidate areas, allocation and construction cost assumptions, and MG boundary.
- `03_Nodal_Siting/`: optimized connection assignments for regional 12-area versus local four-northern-area cases, under both local consumption and export stress screening. `new_capacity_mw` is **incremental assigned generation/storage**, with distributed PV handled outside these high-voltage connection assignments; do not sum as if it were the full portfolio.
- `04_Congestion_And_Expansion/`: candidate added parallel circuits, remaining bottlenecks, scenario overloads, and summary comparison. Costs and heat-limit tests are **model proxies**, not a construction-ready plan.

## Important methodological caveats / 注意事项
1. 2050 has **no official native PWF grid case in these records**. The 2050 screening reuses the 2035 network, with candidate new parallel circuits considered only in expansion scenarios.
2. DC/PTDF and the 283 monitored high-voltage line subset do not cover full AC, voltage, reactive power, transformer, stability or N-1 feasibility. Raw `branches` file has 1,890 branches; the monitored 283 are an analysis subset, not the full regional network.
3. The 2035 and 2050 portfolios are the fixed outcomes used by the latest local-vs-regional comparison, with new capacities of 3.217 GW and about 30.101 GW. The 2050 scenario is a strict fossil-free model scenario, not a demonstrated official future grid.
4. Do not interpret crosswalk geocoding or candidate sites as approved interconnections; per-project siting, resource ceilings and line CAPEX contain research assumptions.
5. Hourly dispatch and macro inputs are consistent with the REFRESH_2035/REFRESH_2050 portfolio copies in the source archive, but remain modeled scenarios rather than observed 2035/2050 outputs.
6. This is a **curated copy of prior analyses**, not a new optimization or a live grid-data update.

## Quick start
- Read `01_Energy_Portfolio/portfolio_2035_updated.csv` and `portfolio_2050_updated.csv`.
- Read `02_Grid_Reference_2035/grid_2035_buses.csv` and `grid_2035_branches.csv` to construct the fixed DC network.
- Join `03_Nodal_Siting/2050_regional_12_areas_mg_local_consumption_chosen_sites.csv` to bus IDs to apply the 2050 modeled injection allocation.
- Consult `04_Congestion_And_Expansion/2050_regional_12_areas_mg_local_consumption/*` for candidate parallel circuits and residual congestion.

`MANIFEST.json` records the internal source archives and members. `SHA256SUMS.txt` provides per-file checksums.
