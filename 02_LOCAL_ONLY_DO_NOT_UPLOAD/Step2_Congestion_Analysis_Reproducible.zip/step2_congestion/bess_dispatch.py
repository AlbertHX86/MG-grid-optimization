from pathlib import Path
import numpy as np,pandas as pd,json
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import splu
from scipy.optimize import linprog
P=Path('/mnt/data/step2_congestion/MG_Nodal_Connection_Optimization'); O=Path('/mnt/data/step2_congestion/results')
B=pd.read_csv(P/'inputs/pwf_2035_buses.csv');L=pd.read_csv(P/'inputs/pwf_2035_branches.csv');S=pd.read_csv(P/'outputs/2050_ROBUST_distributed_MG_load_border_585_PV35to90_pen1p0_selected.csv')
ids=B.id.to_numpy(int); idx={int(k):i for i,k in enumerate(ids)};N=len(B);M=len(L)
f=L.f.map(idx).to_numpy(int);t=L.t.map(idx).to_numpy(int);w=1/(L.x.to_numpy(float)*L.tap.to_numpy(float));rate=L.rate.to_numpy(float)
A=coo_matrix((np.r_[np.ones(M),-np.ones(M)],(np.r_[np.arange(M),np.arange(M)],np.r_[f,t])),shape=(M,N)).tocsr()
ref=idx[585];free=np.r_[np.arange(ref),np.arange(ref+1,N)];AF=A[:,free];Y=(AF.T@AF.multiply(w[:,None])).tocsc();lu=splu(Y)
kv=B.kv.to_numpy(float);state=B.state.to_numpy(int)
monitor=np.where((L.kind=='line').to_numpy()&(L.rate.between(100,9998).to_numpy())&(L.x.to_numpy()>0)&(np.minimum(kv[f],kv[t])>=230)&((state[f]==11)|(state[t]==11)))[0]
PFAC={'solar_central':.7,'bio':.5,'small_hydro':.6,'wind_site':.5,'biogas':.7,'bess':0}
loadidx=np.flatnonzero((B.state==11)&(B.pd>0));weight=B.pd.to_numpy()[loadidx];weight/=weight.sum()
base=(B.pg-B.pd).to_numpy(float)
bs=S[S.tech=='bess'].groupby('bus_id').new_capacity_mw.sum();bus_ids=bs.index.to_numpy(int);caps=bs.to_numpy(float);nb=len(bus_ids)
# sensitivity to battery injections from one reference bus; sum dispatch=0 so reference choice cancels
G=np.zeros((len(free),nb))
for j,b in enumerate(bus_ids):
 ii=idx[b]; G[:,j]= (np.arange(N)!=ref)[free]*(free==ii)
Q=lu.solve(G);PTDF=w[monitor,None]*(AF[monitor,:]@Q)

records=[];rows=[]
for bal in ['border_585','distributed_MG_load']:
 for pv in [.35,.70,.90]:
  inj=base.copy();tot=0
  for a in S.itertuples(index=False):
   fact=pv if a.tech=='solar_central' else PFAC[a.tech]
   q=float(a.new_capacity_mw)*fact;inj[idx[int(a.bus_id)]]+=q;tot+=q
  dg=7944.*pv;inj[loadidx]+=weight*dg;tot+=dg
  if bal=='border_585':inj[ref]-=tot
  else:inj[loadidx]-=weight*tot
  flow=w[monitor]*(AF[monitor,:]@lu.solve(inj[free]))
  # Variables: discharging MW (positive injection), charging MW (negative injection), and branch overflow MW.
  # Absolute throughput penalty prevents artificial simultaneous charge/discharge.
  nr=len(monitor);objective=np.r_[np.ones(2*nb)*1e-3,np.ones(nr)]
  mat=np.zeros((2*nr,2*nb+nr));mat[:nr,:nb]=PTDF;mat[:nr,nb:2*nb]=-PTDF;mat[:nr,2*nb:]=-np.eye(nr)
  mat[nr:,:nb]=-PTDF;mat[nr:,nb:2*nb]=PTDF;mat[nr:,2*nb:]=-np.eye(nr)
  rhs=np.r_[rate[monitor]-flow,rate[monitor]+flow]
  eq=np.zeros((1,2*nb+nr));eq[0,:nb]=1;eq[0,nb:2*nb]=-1
  # Power limit at each battery, plus no net energy production in the snapshot
  capmat=np.zeros((nb,2*nb+nr));capmat[:,0:nb]=np.eye(nb);capmat[:,nb:2*nb]=np.eye(nb)
  res=linprog(objective,A_ub=np.vstack((mat,capmat)),b_ub=np.r_[rhs,caps],A_eq=eq,b_eq=[0],bounds=[(0,None)]*(2*nb+nr),method='highs')
  if not res.success:raise RuntimeError(res.message)
  dispatch=res.x[:nb]-res.x[nb:2*nb]
  f2=flow+PTDF@dispatch;exc=np.maximum(0,np.abs(flow)-rate[monitor]);exc2=np.maximum(0,np.abs(f2)-rate[monitor])
  rec={'balancing':bal,'pv_factor':pv,'baseline_excess_mw_sum':float(exc.sum()),'after_bess_excess_mw_sum':float(exc2.sum()),'reduction_mw_sum':float(exc.sum()-exc2.sum()),'charged_mw':float(res.x[nb:2*nb].sum()),'discharged_mw':float(res.x[:nb].sum()),'bess_net_mw':float(dispatch.sum()),'n_overloaded_after':int((exc2>1e-4).sum())}
  print(rec,flush=True);records.append(rec)
  for bus,cap,u in zip(bus_ids,caps,dispatch):rows.append({'balancing':bal,'pv_factor':pv,'bus_id':int(bus),'bess_capacity_mw':cap,'dispatch_mw':u})
pd.DataFrame(records).to_csv(O/'battery_spatial_shift_sensitivity.csv',index=False)
pd.DataFrame(rows).to_csv(O/'battery_dispatch_by_node.csv',index=False)
