# Step 2 — Congestion Relief 初步实算与复现包

本包包含原有固定的2035、2050选址配置（来自之前的节点MILP结果）、EPE 2035导出母线和线路参数及三个新增分析脚本。原数据位于 `MG_Nodal_Connection_Optimization/inputs` 和 `MG_Nodal_Connection_Optimization/outputs`。

## 运行（在本目录）

```bash
python -m pip install -r requirements.txt
python sim_parallel_2035.py
python sim_parallel.py
python bess_dispatch.py
python audit_step2.py
python make_report.py
```

其中 `sim_parallel*.py` 使用EPE 2035 PWF单个参考工况，2035只做6组参考工况，2050在固定2035拓扑上，按已选能源和场址模拟不同PV同时出力与功率平衡方式。程序建立母线DC矩阵并求解潮流，每加一条沿原走廊的**假设并行回路**，就更新拓扑和电抗矩阵并重算；不是只修改线路容量数值。最多增加10条，按单位假设建设费造成的六情景热限超额下降选择，属于贪心算法而非全局最优混合整数输电扩建。GIS端点必须可配准。施工费只用项目参考线路单价、两端间隔费和投影距离×1.25，不是审批报价。

`bess_dispatch.py` 独立计算**单时刻**BESS在不同母线充放电（净零）的空间调度，上界均受所选BESS功率限制，不建跨小时SOC与能量循环；因此不可用于保证全年电力供需平衡。

`results/six_scenario_comparison.csv`：2050原拓扑与九次假设扩建后的6组DC工况超额。`results/parallel_line_greedy_sequence.csv`：每一个候选回路及估价。`results/battery_spatial_shift_sensitivity.csv`：单时刻BESS的灵敏度上界。`results_2035/six_scenario_comparison.csv`：2035评估。`results/congestion_comparison.png`：比较图。

## 边界（必须读）

1. **2050不是已建立的2050网架**：这是将2050候选资产放在2035规划网架的压力分析。
2. 增量电力采用**州外母线585吸收**或**州内MG负荷比例吸收**两种条件性功率平衡。前者与此前严格无进口2050宏观运行情景并不一致，不可用于证明2050零进口可行。
3. 以EPE 2035母线 P_G-P_D 重算DC基准，未复现原参考AC边界电压控制；DC与AC的线路潮流会有差异。
4. 六情景超额的合计仅为筛查指标，不能当成一个时刻的缺口或年度ENS。
5. 线路候选为**已存在走廊的复制回路**，尚未验证走廊可用性、环境、征地、保护、N-1和成本完整性；2035 DC无过载不表示AC无越限。
6. 当前用的是**上一轮节点选址候选组合**；最新技术系统成本方案如果更新了具体容量和站点，须更新输入并重新求解，不能视作最终Step 1的新组合已经完整联算。

## 结果摘要

- 2035：该DC代表工况中的6个情景，283条高压监测线路没有额外热限超额；此前AC/变压器/电压越限仍存在。
- 2050：在这6个假设情景，原拓扑超额指标合计约9,725.48 MW；9条假设并行回路后约242.47 MW，**还未达到全部满足约束**；线路及间隔总价估计约R$3,453.02 million（不折现、不含未列工程）。
- 现有BESS单时刻空间调度：州外平衡高PV情景无改善；州内平衡PV70/90%时超额分别降7.45/19.11 MW，但不能推断全年可行。
