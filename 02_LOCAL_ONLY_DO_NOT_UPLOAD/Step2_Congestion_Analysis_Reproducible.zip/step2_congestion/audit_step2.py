from pathlib import Path
import json,numpy as np,pandas as pd
P=Path(__file__).resolve().parent
b=pd.read_csv(P/'results/six_scenario_comparison.csv')
c=pd.read_csv(P/'results/parallel_line_greedy_sequence.csv')
d=pd.read_csv(P/'results/battery_spatial_shift_sensitivity.csv')
e=pd.read_csv(P/'results_2035/six_scenario_comparison.csv')
assert len(b)==12 and len(d)==6 and len(c)==9 and len(e)==12
assert set(b.model)=={'existing','after_parallel_additions'}
assert np.all(b.sum_excess_mw>=-1e-6)
assert np.all(e.sum_excess_mw.abs()<1e-5)
assert np.all(np.diff(c.excess_mw_sum_six_cases)<0)
assert abs(c.cumulative_cost_million_brl.iloc[-1]-c.assumed_cost_million_brl.sum())<1e-6
assert (d.after_bess_excess_mw_sum <= d.baseline_excess_mw_sum+1e-6).all()
assert d.bess_net_mw.abs().max()<1e-6
assert (d.charged_mw <= 5290.484025+1e-5).all()
base=b.loc[b.model=='existing','sum_excess_mw'].sum();after=b.loc[b.model=='after_parallel_additions','sum_excess_mw'].sum()
assert abs(base-9725.480496634627)<1e-4
assert abs(after-242.47310304568674)<1e-4
print('PASS: 2035 six cases, 2050 12 scenario rows, 9 physical-DC extension iterations, and battery dispatch numerical audits')
print('2050 sum-of-six-scenario excess:',base,'->',after, 'MW; nominal cost',c.assumed_cost_million_brl.sum(),'million BRL')
