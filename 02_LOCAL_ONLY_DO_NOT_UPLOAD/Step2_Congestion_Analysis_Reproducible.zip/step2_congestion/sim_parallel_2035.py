from pathlib import Path
import json, numpy as np, pandas as pd
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import splu
from pyproj import CRS,Transformer

P=Path('/mnt/data/step2_congestion/MG_Nodal_Connection_Optimization')
O=Path('/mnt/data/step2_congestion/results_2035');O.mkdir(parents=True,exist_ok=True)
B=pd.read_csv(P/'inputs/pwf_2035_buses.csv');L=pd.read_csv(P/'inputs/pwf_2035_branches.csv');S=pd.read_csv(P/'inputs/epe_ons_station_crosswalk.csv')
C=json.loads((P/'inputs/cost_assumptions.json').read_text())
sel=pd.read_csv(P/'outputs/2035_ROBUST_distributed_MG_load_border_585_PV35to90_pen1p0_selected.csv')
N=len(B);M=len(L);ids=B.id.to_numpy(int);idx={int(v):i for i,v in enumerate(ids)}
f=L.f.map(idx).to_numpy(int);t=L.t.map(idx).to_numpy(int);w=1/(L.x.to_numpy(float)*L.tap.to_numpy(float))
ref=idx[585];free=np.r_[np.arange(ref),np.arange(ref+1,N)]
pp=B.kv.to_numpy(float);state=B.state.to_numpy(int)
monitor=np.where((L.kind=='line').to_numpy()&(L.rate.between(100,9998).to_numpy())&(L.x.to_numpy()>0)&(np.minimum(pp[f],pp[t])>=230)&((state[f]==11)|(state[t]==11)))[0]
rate=L.rate.to_numpy(float)
# baseline from PWF nodal P instead of AC reference branch flows, so network reinforcement is self-consistent
base=(B.pg-B.pd).to_numpy(float)
loadloc=np.where((B.state==11)&(B.pd>0))[0];loadweights=B.pd.to_numpy()[loadloc];loadweights/=loadweights.sum()
PFAC={'solar_central':.70,'bio':.50,'small_hydro':.60,'wind_site':.50,'biogas':.70,'bess':0.0}
# scenario injection vector: fixed siting; withdrawal equal to generation, at border or MG load weighted
scenarios=[]
for balance in ['border_585','distributed_MG_load']:
 for pv in [0.35,0.70,0.90]:
  inj=base.copy();total=0
  for s in sel.itertuples(index=False):
   fac=pv if s.tech=='solar_central' else PFAC[s.tech]
   q=float(s.new_capacity_mw)*fac
   inj[idx[int(s.bus_id)]]+=q; total+=q
  # distributed PV is allocated to MG loads
  dg=1044.0*pv
  inj[loadloc]+=loadweights*dg;total+=dg
  if balance=='border_585':inj[ref]-=total
  else:inj[loadloc]-=loadweights*total
  scenarios.append({'mode':balance,'pv':pv,'inj':inj})

A=coo_matrix((np.r_[np.ones(M),-np.ones(M)],(np.r_[np.arange(M),np.arange(M)],np.r_[f,t])),shape=(M,N)).tocsr()
Afree=A[:,free]
baseY=(A.T@A.multiply(w[:,None])).tocsc()
# geographical cost for parallel physical candidate corridors - both endpoints must be mapped
S=S[S.pwf_bus_id.notna()&S.lon.notna()&S.lat.notna()].drop_duplicates('pwf_bus_id')
geo={int(a.pwf_bus_id):(float(a.lon),float(a.lat)) for a in S.itertuples()}
trans=Transformer.from_crs('EPSG:4326',CRS.from_proj4('+proj=aeqd +lat_0=-18.8 +lon_0=-45 +datum=WGS84 +units=m +no_defs'),always_xy=True)
def cost_of(l):
 ff=int(l.f);tt=int(l.t)
 if ff not in geo or tt not in geo:return None
 V=int(round(float(B.iloc[idx[ff]].kv)))
 if V not in (230,345,500) or int(round(float(B.iloc[idx[tt]].kv)))!=V:return None
 a,b=trans.transform(*geo[ff]);c,d=trans.transform(*geo[tt]);dist=np.hypot(a-c,b-d)/1000
 if dist<1 or dist>800:return None
 return float(dist*C['route_multiplier_base']*C['line_cost_million_brl_per_km'][str(V)]+2*C['bay_cost_million_brl_per_unit'][str(V)]),dist,V

# Direct solve after modifying topology. Additional parallel circuits have same reactance and rating as their source record.
def calc(extra):
 if extra:
  gg=np.array(extra,dtype=int)
  ai=np.vstack([np.column_stack((f,t)),np.column_stack((f[gg],t[gg]))]);ww=np.r_[w,w[gg]]
  a=coo_matrix((np.r_[np.ones(len(ww)),-np.ones(len(ww))],(np.r_[np.arange(len(ww)),np.arange(len(ww))],np.r_[ai[:,0],ai[:,1]])),shape=(len(ww),N)).tocsr()
 else:a=A;ww=w
 ac=a[:,free];Y=(ac.T@ac.multiply(ww[:,None])).tocsc();lu=splu(Y)
 flows=[]
 for s in scenarios:
  theta=lu.solve(s['inj'][free]);flows.append(ww*(ac@theta))
 flows=np.array(flows)
 rates=np.r_[rate,rate[np.array(extra,dtype=int)]] if extra else rate
 excess=np.maximum(0,np.abs(flows[:,monitor])-rate[monitor])
 # new parallel circuits contribute constraints as well
 if extra:
  exnew=np.maximum(0,np.abs(flows[:,M:])-rate[np.array(extra,dtype=int)])
  excess=np.hstack([excess,exnew])
 return flows,excess

flows0,ex0=calc([])
basegap=float(ex0.sum());worst=float(ex0.max());print('BASE excess sum all cases',basegap,'max line',worst,'violated',int((ex0>1e-5).sum()),flush=True)
# candidate existing real AC lines with primary overload, and geo-verified physical corridors
ranked=np.argsort(-ex0.sum(axis=0)); pool=[]
for j in ranked:
 lineidx=int(monitor[j]); info=cost_of(L.iloc[lineidx]);
 if info and ex0[:,j].sum()>1e-3:pool.append((lineidx,*info))
print('candidate corridors',len(pool), 'top', pool[:12],flush=True)
# single-circuit screening of each candidate and greedy addition while reduction >0
chosen=[];records=[]; current=basegap; cspent=0
for iteration in range(10):
 best=None
 for lineidx,cost,distance,voltage in pool:
  if chosen.count(lineidx)>=3:continue
  fl,ee=calc(chosen+[lineidx]); now=float(ee.sum());reduction=current-now
  if reduction<=1e-3:continue
  score=reduction/cost
  if best is None or score>best[0]:best=(score,lineidx,cost,distance,voltage,now,ee,fl)
 if best is None:break
 score,l,cost,dist,kv,newgap,ee,fl=best
 chosen.append(l);cspent+=cost
 rec={'iteration':iteration+1,'from_bus':int(L.iloc[l].f),'to_bus':int(L.iloc[l].t),'circuit':int(L.iloc[l].c),'kv':kv,'straight_km':dist,'assumed_line_km':dist*1.25,'assumed_cost_million_brl':cost,'cumulative_cost_million_brl':cspent,'excess_mw_sum_six_cases':newgap,'max_excess_mw_one_case':float(ee.max()),'reduction_mw_sum':current-newgap}
 records.append(rec);print(rec,flush=True)
 current=newgap
print('FINAL','added',len(chosen),'excess',current,'cost',cspent)
pd.DataFrame(records).to_csv(O/'parallel_line_greedy_sequence.csv',index=False)
records=[]
for state_name,lines in [('existing',[]),('after_parallel_additions',chosen)]:
 ff,ee=calc(lines)
 for jj,scenario in enumerate(scenarios):
  records.append({'model':state_name,'balance':scenario['mode'],'pv_factor':scenario['pv'],'sum_excess_mw':float(ee[jj].sum()),'n_violations':int((ee[jj]>1e-6).sum()),'max_excess_mw':float(ee[jj].max()),'max_loading_pct_main_monitored':float((np.abs(ff[jj,monitor])/rate[monitor]).max()*100)})
pd.DataFrame(records).to_csv(O/'six_scenario_comparison.csv',index=False)
json.dump({'data_source':'EPE 2035 PWF region model (converted) with 2050 proxy portfolio; NOT the 2050 future grid','method':'Full DC refactorization after adding each identical parallel existing-line circuit; illustrative greedy search','baseline_total_excess_mw_scenarios':basegap,'final_total_excess_mw_scenarios':current,'candidate_corridors':len(pool),'n_parallel_circuits_added':len(chosen),'indicative_construction_cost_million_brl':cspent,'limitations':['Reference nodal injection and DC line parameters not AC-certified','Balancing with border node violates strict 2050 no-import model if interpreted as imported energy','No land, rights-of-way, protection, permits, budget validation','Parallel circuits on existing corridors are hypothetical and are not an optimized global expansion plan']},open(O/'audit_summary.json','w'),indent=2)
