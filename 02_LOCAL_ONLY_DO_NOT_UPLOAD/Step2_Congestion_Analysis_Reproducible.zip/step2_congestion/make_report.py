from pathlib import Path
import json, pandas as pd,numpy as np,matplotlib.pyplot as plt
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate,Paragraph,Table,TableStyle,Spacer,Image,PageBreak
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.colors import HexColor,black
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
P=Path('/mnt/data/step2_congestion');O=P/'results';O.mkdir(exist_ok=True)
a=pd.read_csv(O/'parallel_line_greedy_sequence.csv')
b=pd.read_csv(O/'six_scenario_comparison.csv');c=pd.read_csv(O/'battery_spatial_shift_sensitivity.csv')
d=pd.read_csv(P/'results_2035'/'six_scenario_comparison.csv')

# Important: rows labelled 'after_parallel_additions' are 2050 physically recalculated DC system after hypothetical circuit additions.
fig,ax=plt.subplots(figsize=(10.5,5),dpi=150)
lab=[];ref=[];post=[];bat=[]
for bal in ['border_585','distributed_MG_load']:
 for pv in [.35,.7,.9]:
  q=b[(b.balance==bal)&(b.pv_factor==pv)]
  r=c[(c.balancing==bal)&(c.pv_factor==pv)].iloc[0]
  lab.append(('External' if bal=='border_585' else 'MG load')+f' / PV {int(pv*100)}%')
  ref.append(float(q[q.model=='existing'].sum_excess_mw.iloc[0]));post.append(float(q[q.model=='after_parallel_additions'].sum_excess_mw.iloc[0]));bat.append(float(r.after_bess_excess_mw_sum))
x=np.arange(6);wid=.26
ax.bar(x-wid,ref,width=wid,color='#303030',label='Original DC topology')
ax.bar(x,bat,width=wid,color='#8A8A8A',label='Battery snapshot shift')
ax.bar(x+wid,post,width=wid,color='#CECECE',edgecolor='#555555',label='9 parallel-circuit additions')
ax.set_xticks(x,lab,rotation=24,ha='right',fontsize=9);ax.set_ylabel('Sum of thermal-rating excess within scenario (MW)')
ax.set_title('2050 portfolio on a frozen 2035 DC network — scenario screening',loc='left',fontsize=12)
ax.grid(axis='y',alpha=.18);ax.set_axisbelow(True);ax.spines[['top','right']].set_visible(False)
ax.legend(frameon=False,ncol=3,fontsize=8,loc='upper left');fig.tight_layout()
fig.savefig(O/'congestion_comparison.png',dpi=220,bbox_inches='tight');fig.savefig(O/'congestion_comparison.pdf',bbox_inches='tight');plt.close(fig)
fig,ax=plt.subplots(figsize=(10.5,4.5),dpi=160)
ax.plot([0]+a.iteration.to_list(),[float(b[b.model=='existing'].sum_excess_mw.sum())]+a.excess_mw_sum_six_cases.tolist(),'-o',color='#333333',lw=1.8,markersize=4)
ax.set_xlabel('Number of additional parallel-circuit candidates');ax.set_ylabel('Sum of MW excess across six cases');ax.grid(alpha=.2);ax.spines[['top','right']].set_visible(False)
ax2=ax.twinx();ax2.plot([0]+a.iteration.to_list(),[0.]+a.cumulative_cost_million_brl.tolist(),'--s',color='#888888',lw=1.6,markersize=3)
ax2.set_ylabel('Indicative construction cost (million R$)')
fig.tight_layout();fig.savefig(O/'circuit_greedy_tradeoff.png',dpi=220,bbox_inches='tight');plt.close(fig)

pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='CNTitle',fontName='STSong-Light',fontSize=18,leading=26,spaceAfter=16))
styles.add(ParagraphStyle(name='CNH',fontName='STSong-Light',fontSize=12.2,leading=19,spaceBefore=12,spaceAfter=7))
styles.add(ParagraphStyle(name='CN',fontName='STSong-Light',fontSize=9.6,leading=16,spaceAfter=7))
styles.add(ParagraphStyle(name='CNsmall',fontName='STSong-Light',fontSize=8,leading=12,spaceAfter=5))
styles.add(ParagraphStyle(name='ENsmall',fontName='Helvetica',fontSize=8,leading=11))
story=[]
def para(t,st='CN'):story.append(Paragraph(t,styles[st]))
def table(rows,widths):
 t=Table(rows,colWidths=widths,repeatRows=1,hAlign='LEFT')
 t.setStyle(TableStyle([('FONTNAME',(0,0),(-1,-1),'STSong-Light'),('FONTSIZE',(0,0),(-1,-1),8),('LEADING',(0,0),(-1,-1),11),('BACKGROUND',(0,0),(-1,0),HexColor('#EDEDED')),('GRID',(0,0),(-1,-1),0.35,HexColor('#BDBDBD')),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]))
 story.append(t)

para('Step 2：Congestion Relief — 电网扩建与储能调度的可复算筛查','CNTitle')
para('研究边界：固定先前求解的2035、2050新增能源组合及代理接入位置，以EPE 2035单个PWF参考工况为拓扑，使用DC模型比较新增并行线路与既有储能的单时刻潮流影响。2050没有独立的官方拓扑，本报告不是最终工程扩建方案。')
para('1. 数据与求解方法','CNH')
para('输入：EPE 2035导出的1,489母线、1,890支路，已核验的站址映射，上一轮MILP得到的2035/2050代理接入点及BESS装机，EPE 230/500 kV参考线路单价。筛查283条高压实体线路；2035和2050均评估光伏35%、70%、90%的出力及两种功率平衡方式，合计每个年份6个场景。')
para('新增并行线路：从出现热限超额、且两端具备地理配准的现役线路中选择候选。每增加一条同走廊、同电抗和额定的假设并行回路，重建DC节点电纳矩阵并重新解六个场景。按单位假设成本带来的超额下降进行贪心选择，不声称全局最优。')
para('储能：仅测试2050已配置BESS节点之间的正负等量功率转移，每站不超过功率上限；不包含SOC、时序充电可行性或AC无功。因此是单时刻灵活性的乐观上界，不是可投入运行的调度方案。')
para('2. 已完成的数值结果','CNH')
base=float(b[b.model=='existing'].sum_excess_mw.sum());end=float(b[b.model=='after_parallel_additions'].sum_excess_mw.sum());cost=float(a.cumulative_cost_million_brl.iloc[-1])
table([['测试','2035','2050'],['原2035 DC网架所查热限','6个测试无额外超额',f'六情景超额合计 {base:,.1f} MW'],['并行回路改造','无需增加（仅此DC子集）',f'假设增加 {len(a)} 条回路'],['改造后热限超额','0 MW',f'{end:,.1f} MW（仍超限）'],['线路+间隔估价','0',f'{cost:,.1f} 百万 R$（未折现）']], [150,165,175])
para('以上“六情景合计”是六次独立潮流筛查下的绝对超额求和，不能解释为一个时刻的输电容量缺口，也不能用来预测年度弃电量。并行线路费用按地理直线距离×1.25及线路/两个间隔单价计算，未包含土地、许可、特殊设备、线路选线及无功改造。','CNsmall')
story.append(Spacer(1,8));story.append(Image(str(O/'congestion_comparison.png'),width=480,height=228))
para('3. 线路扩建候选（研究级）','CNH')
rows=[['编号','线路母线','kV','线路里程 km','估计投资 百万R$']]
for k,r in a.iterrows():rows.append([str(int(r.iteration)),f"{int(r.from_bus)} → {int(r.to_bus)}",str(int(r.kv)),f"{r.assumed_line_km:.1f}",f"{r.assumed_cost_million_brl:,.1f}"])
table(rows,[55,130,62,110,133]);story.append(Spacer(1,9));story.append(Image(str(O/'circuit_greedy_tradeoff.png'),width=470,height=205))
para('4. 储能调度实验与结果解释','CNH')
para('已配置储能所在节点进行同时的充/放电组合，保持总注入不变。州外平衡的70%、90%光伏场景没有缓解热限；MG内部负荷平衡时，70%和90%光伏场景的超额分别降低约7.45 MW和19.11 MW，远低于主要拥塞。该结论受现有BESS代理位置和单时刻模拟限制，不能外推全年。')
para('5. 当前尚不能宣称的结论','CNH')
para('（1）新增9条并行线路不代表已获批建设项目；（2）2050年完全无进口与“州外边界吸收增量发电”的潮流平衡情景在经济含义上不一致，后者仅作灵敏度压力；（3）模型尚有AC电压、变压器额定和动态稳定问题；（4）2050仍存在超限，未求得全面满足所有网络约束的扩建方案；（5）贪心选择不保证建设费最优。')
para('因此，现阶段已完成的是“拓扑会变化的新增并行回路DC模拟”和“储能单时刻空间转移的上界测试”，并非完整的Grid-Constrained Investment Optimum。')
para('6. 复现方式','CNH')
para('依次运行 python sim_parallel_2035.py、python sim_parallel.py、python bess_dispatch.py、python make_report.py；输出位于results和results_2035。请使用requirements.txt配置NumPy、pandas、SciPy、pyproj、matplotlib与reportlab。')
path=P/'Step2_Congestion_Relief_Review.pdf'
doc=SimpleDocTemplate(str(path),pagesize=A4,leftMargin=46,rightMargin=46,topMargin=44,bottomMargin=44)
doc.build(story)
print(path)
