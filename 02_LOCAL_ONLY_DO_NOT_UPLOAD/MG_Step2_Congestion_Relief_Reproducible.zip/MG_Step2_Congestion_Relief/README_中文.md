# MG Step 2：Congestion Relief — 实际求解与复现手册

日期：2026-11-10。**不更改 Step 1 的能源组合**：2035新增3.217 GW；2050新增30.101 GW（扩展技术组合），固定既有的节点分配。

## 这份包做到了什么？

1. 载入EPE 2035 PWF提取的1,489个母线和1,890条支路。
2. 对283条具备参考热限的高压线路建立增量DC/PTDF检查，检验35%、70%、90%光伏出力与两种平衡方式。
3. 在具有可核对两端站址的**现有走廊**提出新增并行回路；每次添加后修改节点电纳矩阵并重新求解，避免直接把原PTDF用于新网架。
4. 区分两种运行边界：`distributed_MG_load`（新增发电在MG负荷区内部消纳）和 `border_585`（由BA州母线585吸收额外注入，**只是州际输送压力敏感性**）。
5. 再用LP计算若有充足的备用发电进行等量补发，理论上需要降低多少新光伏/风电出力。未验证真实备用可用性和BESS SOC。
6. 对模型结果和已有PTDF筛查进行29项独立复核。

## 结果怎么读？

| 情景 | 最严重工况超限合计：无扩建 (MW) | 测试新回路（条） | 扩建后仍超限 (MW) | 假设回路费用 (million R$) |
|---|---:|---:|---:|---:|
| 2035 六工况 | 0 | 0 | 0 | 0 |
| 2050 MG本地消纳（3工况） | 698.403 | 7 | 171.839 | 236.926 |
| 2050 含州外输送敏感性（6工况） | 8779.479 | 12 | 172.307 | 4424.920 |

**最重要：以上两个2050方案都没有通过所有监测线路热限。不能说“拥塞已经解决”。**

保留的关键瓶颈：Bus 1646–4475（Timóteo–Aperam）和1609–1613（João Monlevade附近），分别对应最严本地情景约135.6 MW、36.2 MW超额。一个为短站间连接，另一个缺少完整站址，不应套用长距离线路公里造价。

新增回路费用为2025价格层面的研究假设：连接直线长度 × 1.25绕行 × 电压等级单位造价 + 端点间隔。含州外输送方案中有多个从Bahia连接MG北部的500kV假设新回路，不代表政策必须要求这项建设。未计真实征地、环境许可、新线走廊、完整站内间隔成本等。

## 快速运行

在Python 3.11或以上环境：

```bash
python -m pip install -r requirements.txt
python step2_model.py            # 2035、2050六工况；12条候选并行回路
python local_only_run.py         # 2050 MG内部消纳三工况；7条候选回路
python redispatch_compare.py     # 比较建线前后、假设补发条件下的纠正调度
python audit_step2.py            # 检验数值约束与输入一致性；应显示PASS 29 checks
python create_outputs.py        # 绘制图像
```

* 若需要重新编译中文PDF，已安装XeLaTeX时执行：

```bash
cd report
xelatex -interaction=nonstopmode -halt-on-error MG_Step2_Congestion_Study.tex
```

## 文件指南

- `MG_Nodal_Connection_Optimization/inputs/`：2025/2035相关节点支路、候选站址及技术新增容量。
- `MG_Nodal_Connection_Optimization/outputs/*selected.csv`：上一轮固定的候选节点选址。
- `results/2035_scenario_comparison.csv`、`results/2050_scenario_comparison.csv`：六工况、扩建前后线路热限超额。
- `results/local_only/2050_scenario_comparison.csv`：MG内部消纳的2050三工况。
- `results/*parallel_line_candidates.csv`：逐个候选并行回路及参考成本。
- `results/*remaining_bottlenecks.csv`：扩建后仍然过载的真实模型支路。
- `results/redispatch_comparison.csv`：所需替代调度，**不保证供应可用**。
- `results/audit_summary.json`：29项检查结果。
- `figures/`：高分辨率及矢量图。
- `report/`：中文LaTeX报告及编译PDF。

## 关键技术界限

- EPE 2035 PWF是一个代表性规划工况，不是完整逐时节点序列；2050复用2035拓扑，因此不能据此声明实际2050线路建设计划。
- 原AC有功潮流用于校准初始值，增量使用DC线性化；新增并行回路按相同电抗及参考偏置加入。**这不是扩建后的AC验证**。
- 原始热额定单位MVA，本轮对所选高压线路用有功MW近似，不包括变压器、低压设施、电压/无功、N-1、频率稳定、配电。
- 贪心式回路选取**不是全局最优的线路扩建MILP**。仅报价具有可用两端地理位置的候选，不对缺数据线路填造数字。
- 项目级风电、生物气可开发容量和2050无化石资源假设尚未工程核实。
- Step 1的技术系统成本独立报告；本轮对新线路的金额**不能直接加成已通过验收的总系统预算**。

## 参数来源

`inputs/cost_assumptions.json`标注了EPE 2025报告参考线路/间隔造价，具体工程费用、站址、路线系数均有明确研究假设。EPE工程信息主页： https://www.epe.gov.br/pt/areas-de-atuacao/energia-eletrica/planejamento-da-transmissao/estudos-de-planejamento 。
