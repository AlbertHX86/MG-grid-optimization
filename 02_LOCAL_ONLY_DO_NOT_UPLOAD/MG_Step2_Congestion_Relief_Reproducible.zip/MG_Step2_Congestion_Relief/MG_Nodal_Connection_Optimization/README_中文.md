# Minas Gerais：带选址与接网成本的下一轮优化

## 这次实际完成了什么？

本研究**先固定已解出的技术组合，再优化各技术所在的候选区域、接入的EPE/ONS变电站以及接入回路数**。每个研究年份有一个共同的接网方案，它同时通过六个事先声明的PTDF场景。模型包括具体的架空线、变电站间隔、升压设备和分布式光伏配网费用代理。

随后，将第一次选址模型估算的**技术平均接网CAPEX**加回8,760小时的2035和2050容量扩张LP，**仅重新求解一次**，最后再对更新后的技术总量做节点选址优化。这不是发电技术、8,760小时调度、逐节点投资和线路建设一次联立求解的全局最优解。

**特别注意：Stage 3 的 `thermal_uplift_mw` 只是针对所监测线路的连续热容量增补代理，不是真实新线路，也不是可直接定价的新输电项目。2050是冻结2035规划网络的压力情景。**

## 文件夹结构

- `inputs/`：来源在以前交付包中已经归档的2025设备/成本参数、2035 EPE PWF母线和支路、候选市镇坐标、ONS变电站地理坐标交叉表、2035/2050最初及更新的Portfolio。
- `macro_reopt/macro/processed/`：宏观8,760小时输入与模型参数。
- `macro_reopt/optimization/`：修改后的宏观容量LP代码、情景配置。
- `macro_reopt/output/REFRESH_2035`、`REFRESH_2050`：LP重新求解的portfolio、调度、求解器状态。
- `code/optimize_siting.py`：建立2035 DC/PTDF、候选区域到变电站、整数回路、拥塞增补的MILP。
- `code/run_robust.py`：只运行单次MILP。
- `code/run_all.py`：完整、两轮反馈式重算。
- `code/audit_and_plot.py`：独立复核结果并绘图。
- `outputs/`：全部场景结果、逐站容量、线路增补、审计表。
- `figures/`：成本对比图、2050拥塞压力图、2035和2050区域连接图。
- `report/MG_Nodal_Connection_Optimization_Study.pdf`：中文3页技术结论与局限。

## 运行方式

建议先验证解压文件是否完整：`sha256sum -c SHA256SUMS.txt`（Mac可用`shasum -a 256 -c SHA256SUMS.txt`）。**运行模型后，有些输出文件会被重新生成，完整快照哈希不再相同是正常现象。** 此时只检查不可变的原始输入：`sha256sum -c IMMUTABLE_SHA256SUMS.txt`。


推荐Python 3.12或3.13。终端进入本目录，执行：

```bash
python -m pip install -r requirements.txt
bash RUN_ALL.sh
```

Windows系统在PowerShell中可运行：

```powershell
py -m pip install -r requirements.txt
py code/run_all.py
```

如只想重跑2035的6情景MILP，使用：

```bash
python code/run_robust.py --years 2035 --balance-modes distributed_MG_load border_585 --pv 0.35 0.70 0.90 --penalty 1
```

如只想检查已保存结果、重画图：

```bash
python code/audit_and_plot.py
```

### 结果读法

`outputs/2035_ROBUST_distributed_MG_load_border_585_PV35to90_pen1p0_summary.json` 和2050同名文件中：

- `reference_connection_nominal_mbrl`：相同PWF匹配资格条件下，原代表区域容量比例+最近候选站的接网费用，单位百万R$。
- `optimized_connection_nominal_mbrl`：节点MILP选址、整数回路优化后的接网费用，百万R$。二者可比较。
- `optimized_worstcase_uplift_mw`：为让**同一接网方案**通过6种PTDF场景所允许的线路热额定增补合计，单位MW；不是工程造价。
- `mip_gap`：MILP最优性间隙；`max_constraint_violation`、`capacity_error_mw`是数值残差。

`*_selected.csv` 的 `area`, `station`, `bus_id`, `new_capacity_mw`, `circuits`, `route_length_km`, `connection_cost_mbrl` 可检查每项投资被分到哪里。
`*_cases.csv` 显示6个测试工况中优化前后有功线路超额和热负载。`INDEPENDENT_AUDIT.csv` 逐项校验技术容量、接线数量、逐时平衡和约束。

## 主要数值（2025口径未折现估算费用）

| 项目 | 2035 | 2050 |
|---|---:|---:|
| 新增容量，含储能 (GW) | 3.217 | 30.101 |
| 代表分配接网费用（十亿R$） | 1.401 | 5.521 |
| 优化接网费用（十亿R$） | 0.878 | 4.593 |
| 接网费用下降 | 37.31% | 16.81% |
| 跨6场景线路热额定增补代理(MW) | 0 | 9,478 |

**注意：** 此次代表分配和优化解都使用经PWF地理匹配的候选站，与以前“所有ONS最近站”所得的1.138/5.291十亿R$不是同一个可比基准。

## 非真实工程的假设（不可跳过）

1. 候选市镇代表坐标**不是实际项目地块**；按既有代表区域分配上浮50%的建设上限**未做土地、风速、燃料供应和许可核查**。2050风电2GW和生物气0.4GW依旧是研究情景。
2. 接网成本取EPE部分单价和明确设定的138/345kV、回路能力、变压器和配网代理。距离使用局部米制投影欧氏距离乘1.25绕行系数；未做真实线路走廊选址与征地。
3. 只在2035规划网架的283条高压实体线路使用简化DC/PTDF和MW代替MVA限额；**没有完整电压、无功、变压器、N-1和AC验收**。EPE 2035基准中可能已经包含未来项目，新增容量叠加存在双计风险，需要先对齐存量和未来项目清单。
4. 2050沿用2035网架、2035参考潮流及负荷分布；极端州外边界吸收新增电力是敏感性情景，不代表已预测的电力交换。
5. 储能在PTDF筛查里零净功率，只优化接入位置和接入成本，没有把储能无时序出力当作免费拥塞缓解。
6. `penalty=1`的R$百万/MW是线路热限增补的**情景权重**，不是经过核实的真实输电扩建工程单价，不能将联合目标函数数值称为工程支出。
7. 2050本地零化石、零进口是严格研究边界，不等价于经过生命周期及进口碳核算的真正碳中和。
8. 宏观LP目标按2025末折现并计资产残值；接网表为2025价格的名义投资额，两个数不能简单相加成为完整社会成本。软件中加回的是技术单位接网成本的近似边际项，仅作一次反馈。

## 本次验证

已经在独立目录实际运行`RUN_ALL.sh`，2035/2050两个容量LP求解器返回最优，6情景共用选址MILP的两个规划期均成功，三档惩罚系数敏感性复算成功；30项独立数值审计全部通过。求解与数学约束通过不意味着现实并网可行。

## 官方数据与造价来源

- EPE输电仿真资料：https://www.epe.gov.br/pt/areas-de-atuacao/energia-eletrica/planejamento-da-transmissao/bases-de-dados-de-simulacao
- EPE 2025输电投资参考：https://www.epe.gov.br/sites-pt/publicacoes-dados-abertos/publicacoes/PublicacoesArquivos/publicacao-276/topico-755/EPE-DEE-RE-071-2025-rev0.pdf
- ANEEL BPR造价参考：https://dadosabertos.aneel.gov.br/dataset/bpr-banco-de-precos-de-referencia-linha-de-transmissao

**本研究包包含复现所用的已处理PWF、ONS站址交叉表和宏观逐时输入，但未重新分发EPE全部原生PWF压缩档案。**
