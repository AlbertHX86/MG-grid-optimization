#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
unzip -q -o source_reference.zip
python -m pip install -r MG_Step2_Congestion_Relief/requirements.txt
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python optimize_scope.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python evaluate_parallel_lines.py
